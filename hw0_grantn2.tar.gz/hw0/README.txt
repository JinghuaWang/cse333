Name: Grant Neubauer
Student Number: 1411339
UW email: grantn2@uw.edu

The magic word is: DEADBEEF